package com.viettel.imdb.rest.mock.server;

public enum NodeState {
    STOP,
    RUNNING
}
