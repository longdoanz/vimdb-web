package com.viettel.imdb.rest.mock.app;

public class ApplicationSimulator {
}
