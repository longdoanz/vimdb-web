package com.viettel.imdb.rest.controller;

/**
 * @author quannh22
 * @since 08/08/2019
 */
public class OperateController {
    // restart servers
    // settings Backup/Restore process, etc.
}
