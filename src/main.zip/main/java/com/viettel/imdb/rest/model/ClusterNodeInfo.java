package com.viettel.imdb.rest.model;

public class ClusterNodeInfo {
    private String name;
    private String ip;
    private String version;
    private long uptime;
    private String os;
    private long heartbeatSent;

    private long heartbeatReceived;
    private float ramUsagePercentage;
    private float diskUsagePercentage;

}

class ClusterNodeDataInfo {

}
