package com.viettel.imdb.rest.util;

/**
 * @author quannh22
 * @since 09/08/2019
 */
public class VIMDBRestConstant {
    private VIMDBRestConstant(){}
    public static final String FIELD_NAME_LIST = "fieldnames";
}
