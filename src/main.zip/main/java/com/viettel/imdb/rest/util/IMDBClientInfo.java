package com.viettel.imdb.rest.util;

/**
 * @author quannh22
 * @since 03/10/2019
 */
public class IMDBClientInfo {
}
